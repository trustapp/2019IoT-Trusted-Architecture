package ntust.idsl.iot2019.app.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "timer")
public class AuthTime {

    @DatabaseField(id = true,columnName = "ID")
    int id;

    @DatabaseField(columnName = "Name")
    String authStatus;

    @DatabaseField(columnName = "Timer")
    double timer;

    public AuthTime(String authStatus, double timer) {
        this.authStatus = authStatus;
        this.timer = timer;
    }

    public AuthTime(){}
}
