package ntust.idsl.iot2019.app;

import android.bluetooth.*;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;


import java.io.IOException;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.UUID;
import ntust.idsl.iot2019.algorithm.*;
import ntust.idsl.iot2019.app.model.SensorData;

public class Sensor implements Serializable {

    private static final UUID SERVICE_UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID TX_CHARACTERISTIC_UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final UUID RX_CHARACTERISTIC_UUID = UUID.fromString("0000ffe2-0000-1000-8000-00805f9b34fb");

    private BluetoothDevice device;
    private Context service;
    private int sensorId;
    //private Handler handler = new Handler();

    public BluetoothGatt mGatt;
    private BluetoothGattCharacteristic txChar;
    private BluetoothGattCharacteristic rxChar;
    private boolean writing; // onCharacteristicWrite()
    private Algorithm alg;

    private String authStatus;
    private long authProcessTime;

    // Data
    private byte[] staticData;   // toPhase2Data = Algorithm.phase1(staticData)
    private  int[] toPhase2Data; // Algorithm.phase2(toPhase2Data)
    private byte[] contData;     // contedData = Algorithm.contPhase(contData)
    private byte[] contedData;
    private byte[] sensorData;

    // Time
    private long preTime;
    private float PERIOD;
    private boolean canEntStatic;

    // Static-Auth
    private boolean authing;
    public boolean runningAuth1;

    // Cont-Auth
    private boolean blocking;
    private boolean canCont2static; // 最後一筆

    // Public
    public boolean boo_canStartNext;
    public boolean auth_interrupt;
    public int numBYauth;
    private Thread authThread;

    // Debug
    private int connectStatus = 123; //測異常state用，還沒寫
    private int contRunnable_debuging = 0; // debug 用
    boolean FF00;
    Long authMs;

    public Sensor (BluetoothDevice device, Context service, int id) {
        this.device = device;
        this.service = service;
        this.sensorId = id;
    }

    void init() {
        authStatus = "";
        authProcessTime = 0;

        preTime = -1;
        PERIOD = 10000;
        canEntStatic = false;

        authing = false;
        runningAuth1 = false;
        blocking = false;
        canCont2static = true;

        authThread = null;
        numBYauth = 12345;
        writing = false;
        auth_interrupt = false;
        boo_canStartNext = false;
        FF00 = false;

        contData = new byte[71]; // for java.lang.NullPointerException: Attempt to read from null array

        alg = new Algorithm();
        authMs = 0L;
    }

    public void start() {
        init();
        Log.d(device.getName()+"-start() "," connectGatt()");
        mGatt = device.connectGatt(service,true, gattCallback);
    }

    // Static-Auth
    private int auth() {
        authProcessTime = System.currentTimeMillis();
        authing = true;
        runningAuth1 = true;

        Log.d(device.getName()+"-AUTH ","Static Phase 1 Start");
        txChar.setValue( new byte[] {0x00, 0x33} );
        mGatt.writeCharacteristic(txChar);

        int num = 0;
        authMs = 0L;
        while (authing && runningAuth1) {
            try {
                num++;
                Thread.sleep(200);
                authMs += 200;

                if (auth_interrupt) {
                    Log.d(device.getName()+"-AUTH ","外部中斷");
                    return -1;
                }
                Log.d(device.getName()+"-AUTH ","TIME + 200 ms (runningAuth1 = true)");
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (num > 100) { // 改回20
                Log.d(device.getName()+"-AUTH ","num = 20");
                return -1;
            }
        }
        Log.d(device.getName()+"-AUTH ","num < 20");

        if(!authing) {
            Log.d(device.getName()+"-AUTH ","TWF 88888888");
            return -1;
        }

        Log.d(device.getName()+"-AUTH ", "Static Phase 1 Done");
        updateAuthStatus("Static Phase 1 Done");

        Log.d(device.getName()+"-AUTH ", "Static Phase 2 Start");
        byte[] toSensor;
        toSensor = alg.phase2(device.getName(), toPhase2Data[0], toPhase2Data[1], toPhase2Data[2]);

        int len = toSensor.length;
        for (int i = 0; i < len; i += 20) {
            if (len - i > 20) {
                txChar.setValue(Arrays.copyOfRange(toSensor, i, i + 20));
            } else {
                txChar.setValue(Arrays.copyOfRange(toSensor, i, len));
            }
            writing = true;
            mGatt.writeCharacteristic(txChar);

            while (writing) {
                try {
                    Thread.sleep(200);
                    authMs += 200;
                    Log.d(device.getName()+"-AUTH ","TIME + 200 ms (writing)");
                } catch (Exception e) {}
            }
            Log.d(device.getName()+"-AUTH ", "Static Phase 2 Sent");
        }
        //updateAuthStatus("Static Phase 2 Done");

        while (authing) {
            try {
                // D/-onCharacteristicChanged: ff000d0a33667ea3b37a1da47d0d 先等authing = false在跑cont，否則有機會它會17送
                Thread.sleep(200);
                Log.d(device.getName()+"-AUTH ","TIME + 200 ms (authing)");
            } catch (Exception e) {}
        }

        Log.d(device.getName()+"-AUTH ", "Static Finished (Next BLE can start.)");
        boo_canStartNext = true;

        return 0;
    }
    public Runnable authRunnable = new Runnable( ) {
        @Override
        public void run() {
            numBYauth = auth();

            if (numBYauth == -1) {
                Log.d(device.getName()+"-authRunnable ", " authThread too long > break");
                // 等待 reConnectThread or onServicesDiscovered()，不然一切結束
            }
            if (numBYauth == 0) {
                Log.d(device.getName()+"-authRunnable ", " authThread success");

                new Thread(contRunnable).start(); // 不影響 isAlive()
                //handler.postDelayed(contRunnable,1000);
            }
        }
    };

    // Cont-Auth
    private int checkCD() {
        if (preTime < 0) {
            preTime = System.currentTimeMillis();
        }

        Log.d(device.getName()+"-CD ", "countdown time: " + (System.currentTimeMillis() - preTime) );
        if (System.currentTimeMillis()-preTime > PERIOD) {
            canEntStatic = true;
            Log.d(device.getName()+"-CD ", "countdown time Reset!  Next will be Static.");
            preTime = System.currentTimeMillis();
            return -1;
        } else {
            return 0;
        }
    }
    private Runnable contRunnable = new Runnable( ) {

        @Override
        public void run() {
            contRunnable_debuging++;
            Log.d(device.getName()+"-contRunnable times:" + contRunnable_debuging," Cont Phase Start");

            int numBYcd = checkCD();

            txChar.setValue( new byte[] {0x00, 0x33} );
            mGatt.writeCharacteristic(txChar);

            blocking = true;
            while (blocking) {
                try {
                    Thread.sleep(200);
                    Log.d(device.getName()+"-contRunnable times:" + contRunnable_debuging," TIME + 200 ms (blocking)");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            Log.d(device.getName()+"-contRunnable times:" + contRunnable_debuging," contedData:" + Hash.bytesToHex(contedData) );

            int len = contedData.length;
            for (int i = 0; i < len; i += 20) {
                if (len - i > 20) {
                    txChar.setValue( Arrays.copyOfRange(contedData, i, i + 20) );
                } else {
                    if (numBYcd == -1) {
                        canCont2static = false; // 最後一筆前先給
                    }
                    txChar.setValue( Arrays.copyOfRange(contedData, i, len) );
                }
                writing = true;
                mGatt.writeCharacteristic(txChar);

                while (writing) {
                    try {
                        Thread.sleep(200);
                    } catch (Exception e) {}
                }
            }

            // 留時間抓ff000d0a > 鑑別結束 > 傳值
            while (!FF00) {
                try {
                    Thread.sleep(100);
                    //Log.d(device.getName()+"-contRunnable times:" + contRunnable_debuging," 88888888");
                } catch (Exception e) {}
            }

            txChar.setValue(new byte[]{0x44, 0x33});
            mGatt.writeCharacteristic(txChar);

            while (FF00) { // update() > FF00 = false
                try {
                    Thread.sleep(100);
                    //Log.d(device.getName()+"-contRunnable times:" + contRunnable_debuging," 77777777");
                } catch (Exception e) {}
            }

            if (numBYcd == 0) {
                Log.d(device.getName()+"-contRunnable "," handler loop");

                new Thread(contRunnable).start();
                //handler.postDelayed(this, 1000);
            } else {
                Log.d(device.getName()+"-contRunnable "," handler finished !");

//                while (!canCont2static) { // 好像用不到了
//                    try {
//                        Thread.sleep(100);
//                    } catch (Exception e) {}
//                }

                canEntStatic = false;
                Log.d(device.getName()+"-contRunnable "," static authThread start");
                authThread = new Thread( authRunnable );
                authThread.start();
            }
        }
    };

    BluetoothGattCallback gattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            Log.d("-gattCallback ", "STATUS = " + String.valueOf(status));
            connectStatus = status;

            if (status == BluetoothGatt.GATT_SUCCESS) {
                updateAuthStatus("Connect success");
                gatt.discoverServices(); // 接 onServicesDiscovered()
                //mGatt = gatt;

            } else if (status == BluetoothGatt.STATE_CONNECTING) {
                updateAuthStatus("Connecting");

            } else if (status == 8) {
                updateAuthStatus("Disconnected");
                authing = true; // 斷?
                //device.connectGatt(service, true, this);
            } else {
                updateAuthStatus("status = " + String.valueOf(status));
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            Log.d("GATT","DW OK");
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            // loop 找 Services & Characteristic

            try {
                txChar = gatt.getService(SERVICE_UUID).getCharacteristic(TX_CHARACTERISTIC_UUID);
                //rxChar = gatt.getService(SERVICE_UUID).getCharacteristic(TX_CHARACTERISTIC_UUID);
            } catch (Exception e) {
                Log.d(device.getName()+"-onServicesDiscovered ", "WTF 88888888");
                e.printStackTrace();
            }

            gatt.setCharacteristicNotification(txChar, true);  // 原來是rx，也只有這裡是
//            Log.d("RXTX",rxChar.toString()+", "+txChar.toString());
//            UUID uuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
//            BluetoothGattDescriptor descriptor = rxChar.getDescriptor(uuid);
//            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
//            gatt.writeDescriptor(descriptor);

            if (authThread == null) { // 0 > 34 > 0 ，重複的問題
                authThread = new Thread( authRunnable );
                authThread.start();
            } else {
                Log.d(device.getName()+"-onServicesDiscovered ", "authThread already exits.  authThread.isAlive(): " + authThread.isAlive() );

                if ( (!authThread.isAlive()) && (numBYauth == -1) && (!auth_interrupt) ) {
                    Log.d(device.getName()+"-onServicesDiscovered ", "authThread = new Thread(authRunnable).start()");
                    authThread = new Thread( authRunnable );
                    authThread.start();
                }
            }
        }

        @Override
        public void onCharacteristicChanged(final BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);

            byte[] data = characteristic.getValue();
//            characteristic.setValue( new byte[]{0} );
//            gatt.writeCharacteristic(characteristic);

            if (authing) {
                if (data[0] == 0x33 && data[1] == 0x66) {
                    Log.d(device.getName() + "-onCharacteristicChanged ", "0x33 0x66");
                    staticData = new byte[93];
                }
                if (runningAuth1) {
                    for (int i = 0; i < data.length; i++) {
                        staticData[i + staticData[92]] = data[i];
                    }
                    staticData[92] += data.length;
                    Log.d(device.getName() + "-onCharacteristicChanged ", "staticData < 92");

                    if (staticData[92] == 92) {
                        Log.d(device.getName() + "-onCharacteristicChanged ", "bytesToHex(staticData): " + Hash.bytesToHex(staticData) );

                        toPhase2Data = alg.phase1(device.getName(), staticData);

                        if (toPhase2Data == null) {
                            mGatt.close();
                            Log.d(device.getName() + "-try Catch ", "mGatt.close()");
                        }

                        runningAuth1 = false;
                    }
                } else {
                    Log.d(device.getName() + "-onCharacteristicChanged ", "ff00 or not: " + Hash.bytesToHex(data));

                    if (Hash.bytesToHex(data).substring(0,4).equals("ff00")) { // 0-3
                        updateAuthStatus("Auth success");

                        //handler.postDelayed(re_runnable,1000); // 兩台一起跑，所以第一筆資料update比較慢
                    } else {
                        updateAuthStatus("Auth failed");
                        Log.d(device.getName() + "-onCharacteristicChanged ", "WTF 88888888");
                    }
                    authProcessTime = System.currentTimeMillis() - authProcessTime - authMs;
                    authing = false;
                }
            } else {
//                Log.d(device.getName() + "-onCharacteristicChanged ", "continu sending data..."); // 大約get兩筆update一次
//                if (data[0] == 0x44) {
//                    sensorData = new byte[12];
//                }
//                StringBuilder b=new StringBuilder();
//                for (int i = 0; i < data.length; i++) {
//                    b.append(String.format("%02x",data[i])); // 十六進 寬2 不足補0  ex. 10 = 0A
//                    sensorData[i+sensorData[11]] = data[i];
//                }
//                sensorData[11] += data.length;
//                if (sensorData[11] == 11) {
//                    updateValue();
//                }

                //Log.d(device.getName() + "-onCharacteristicChanged ","data.length: " + data.length);
                Log.d(device.getName() + "-onCharacteristicChanged ","bytesToHex(data): " + Hash.bytesToHex(data) );

                if (FF00) {//分兩個出來一個四個值，一個兩個值
                    if (data[0] == 0x44 && data[1] == 0x00)
                    {
                        sensorData = new byte[13];
                        for (int i = 0; i < data.length; i++) {
                        sensorData[i+sensorData[12]] = data[i];
                    }
                        sensorData[12] += data.length;

                        if(sensorData[12] == 12)
                        {
                            updateValue();
                            FF00 = false;
                        }
                    }
                    else if (data[0] == 0x44 && data[1] == 0x11)
                    {
                        sensorData = new byte[21];
                        for (int i = 0; i < data.length; i++) {
                            sensorData[i+sensorData[20]] = data[i];
                        }
                        sensorData[20] += data.length;
                        if (sensorData[20] == 20) {  // [0x44][0x11][b_temp(4)][b_humi(4)][b_temp(4)][b_humi(4)][\r][\n] [len]
                            updateValue();
                            FF00 = false;

//                        Log.d(device.getName() + " 0x44 > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,0,1)) );
//                        Log.d(device.getName() + " 0x11 > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,1,2)));
//                        Log.d(device.getName() + " 4 > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,2,6)) );
//                        Log.d(device.getName() + " 4 > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,6,10)) );
//                        Log.d(device.getName() + " 4 > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,10,14)) );
//                        Log.d(device.getName() + " 4 > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,14,18)) );
//                        Log.d(device.getName() + " 0d0a > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,18,20)) );
//                        Log.d(device.getName() + " len > ",Hash.bytesToHex( Arrays.copyOfRange(sensorData,20,21)) );
                        }
                    }


                }

                if (Hash.bytesToHex(Arrays.copyOfRange(data, 0, 4)).equals("ff000d0a")) {

//                    if (canEntStatic) {
//                        Log.d(device.getName() + "-onCharacteristicChanged ","----- ff000d0a Auth from beginning -----");
//                        canCont2static = true;
//
//                    } else if (contData[70] == 70) {
                    if (contData[70] == 70) {
                        Log.d(device.getName() + "-onCharacteristicChanged ","skip ff000d0a");
                        contData = new byte[71];
                        data = Arrays.copyOfRange(data, 4, data.length);
                    } else {
                        Log.d(device.getName() + "-onCharacteristicChanged ","WTF 88888888");
                    }

                    FF00 = true;
                }


                if (!FF00 && data.length != 0) { // for java.lang.ArrayIndexOutOfBoundsException: length=0; index=0
                    if (data[0] == 0x33) { // 要測前置碼會不會分兩次送(sensor分兩次沒差) !!
                        if (data.length > 1 && data[1] == 0x66) {
                            contData = new byte[71];
                        }
                    }

                    for (int i = 0; i < data.length; i++) {
                        contData[i + contData[70]] = data[i];
                    }
                    contData[70] += data.length;
                    Log.d(device.getName() + "-onCharacteristicChanged ","contauthData[70]: " + contData[70]);
                }

                /* contData = new byte[70] = [0x33][0x66][idsn(4)][r2(4)][mt][ms][m5] */
                if (contData[70] == 70) {
                    Log.d(device.getName() + "-onCharacteristicChanged ", "bytesToHex(contauthData): " + Hash.bytesToHex(contData));

                    /* contedData = new byte[42] = [0x66][0x99][y1][ack] */


                    contedData = alg.contPhase(device.getName(), Arrays.copyOfRange(contData, 0, 70), canEntStatic);

                    if (contedData == null) {
                        mGatt.close();
                        Log.d(device.getName() + "-try Catch ", "mGatt.close()");
                    }

                    blocking = false;
                }
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            writing = false;
        }
    };

    private Runnable re_runnable = new Runnable( ) {
        @Override
        public void run ( ) {
            if(!authing) {
                txChar.setValue(new byte[]{0x44, 0x33});
                mGatt.writeCharacteristic(txChar);
                //handler.postDelayed(this, 1000);
            }
        }
    };

    void updateValue() {//一個4個data一個2個data的

        String databaseUrl = "jdbc:mysql://140.118.109.194:3306/iot_trust";

        try {
            ConnectionSource connectionSource = new JdbcConnectionSource(databaseUrl,"user","user");
            Dao<SensorData,String> sensorDataDao = DaoManager.createDao(connectionSource, SensorData.class);

            if(sensorData.length == 13) {
                byte[] b1 = Arrays.copyOfRange(sensorData,2,6); // 2-5
                byte[] b2 = Arrays.copyOfRange(sensorData,6,10); // 6-9
                float f1 = ByteBuffer.wrap(b1).order(ByteOrder.nativeOrder()).getFloat();
                float f2 = ByteBuffer.wrap(b2).order(ByteOrder.nativeOrder()).getFloat();
                Intent updateIntent = new Intent();
                updateIntent.putExtra("data", new float[] {f1, f2} );
                updateIntent.putExtra("name", device.getName());
                updateIntent.putExtra("auth", authStatus);
                updateIntent.putExtra("time", authProcessTime);

                updateIntent.putExtra("sensor", sensorId);
                updateIntent.setAction("li.power.idsl.most.app.SENSOR_UPDATE");
                service.sendBroadcast(updateIntent);

                Log.d(device.getName() + "-tmp ","contauthData[70]: " + contData[70]);

                if(device.getAddress().equals("0C:B2:B7:19:05:B2")) {
                    sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                            "Methane", f1));
                    sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                            "Methane", f2));
                } else if (device.getAddress().equals("0C:B2:B7:19:02:07")) {
                    sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                            "Heart Rate", f1));
                    sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                            "Blood Oxygen Level", f2));
                } else {}
            }

            if(sensorData.length == 21) {
                byte[] b1 = Arrays.copyOfRange(sensorData, 2, 6); // 2-5
                byte[] b2 = Arrays.copyOfRange(sensorData, 6, 10); // 6-9
                byte[] b3 = Arrays.copyOfRange(sensorData, 10, 14); // 10-13
                byte[] b4 = Arrays.copyOfRange(sensorData, 14, 18); // 14-17
                float f1 = ByteBuffer.wrap(b1).order(ByteOrder.nativeOrder()).getFloat();
                float f2 = ByteBuffer.wrap(b2).order(ByteOrder.nativeOrder()).getFloat();
                float f3 = ByteBuffer.wrap(b3).order(ByteOrder.nativeOrder()).getFloat();
                float f4 = ByteBuffer.wrap(b4).order(ByteOrder.nativeOrder()).getFloat();
//            Log.d("b1  >>>>>>   ", Hash.bytesToHex( Arrays.copyOfRange(sensorData,2,6)) );
//            Log.d("b2  >>>>>>   ", Hash.bytesToHex( Arrays.copyOfRange(sensorData,6,10)) );
//            Log.d("b3  >>>>>>   ", Hash.bytesToHex( Arrays.copyOfRange(sensorData,10,14)) );
//            Log.d("b4  >>>>>>   ", Hash.bytesToHex( Arrays.copyOfRange(sensorData,14,18)) );
                Intent updateIntent = new Intent();
                updateIntent.putExtra("data", new float[]{f1, f2, f3, f4});
                updateIntent.putExtra("name", device.getName());
                updateIntent.putExtra("auth", authStatus);
                updateIntent.putExtra("time", authProcessTime);
                updateIntent.putExtra("sensor", sensorId);
                updateIntent.setAction("li.power.idsl.most.app.SENSOR_UPDATE");
                service.sendBroadcast(updateIntent);

                sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                        "Temperature", f1));
                sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                        "Humidity", f2));
                sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                        "PM2.5", f3));
                sensorDataDao.create(new SensorData(device.getAddress(), (int)authProcessTime,
                        "UV Level", f4));
            }

            connectionSource.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void updateAuthStatus (final String txt) {

        Intent authUpdateIntent = new Intent();
        authUpdateIntent.putExtra("data", txt);
        authUpdateIntent.putExtra("name", device.getName());

        authUpdateIntent.putExtra("sensor", sensorId);
        authUpdateIntent.setAction("li.power.idsl.most.app.AUTH_UPDATE");
        authStatus = txt;
        service.sendBroadcast(authUpdateIntent);
    }
}
