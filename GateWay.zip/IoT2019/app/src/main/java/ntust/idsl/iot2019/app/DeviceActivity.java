package ntust.idsl.iot2019.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import ntust.idsl.iot2019.app.model.SensorValue;
import ntust.idsl.iot2019.app.model.SensorValueAdapter;
import ntust.idsl.iot2019.R;

public class DeviceActivity extends AppCompatActivity {

    private SensorValueAdapter sensorValueAdapter;
    private SensorUpdateListener broadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device);

        sensorValueAdapter = new SensorValueAdapter();

        int i = 0;
        SensorValue sv;
        for (String mac : this.getIntent().getStringArrayListExtra("devices")) {
            switch (mac) {
                case "1":
                case "18:62:E4:3D:ED:28":
                    sensorValueAdapter.addSensorValueObject(new SensorValue(), 0);
                    sv = sensorValueAdapter.getSensorValueObject(i++);
                    sv.setValueType1("Methane,  ppm");
                    sv.setValueType2("Methane,  ppm");
                    break;
                case "3":
                case "4":
                    sensorValueAdapter.addSensorValueObject(new SensorValue(), 0);
                    sv = sensorValueAdapter.getSensorValueObject(i++);
                    sv.setValueType1("Heart Rate,  bpm");
                    sv.setValueType2("Blood Oxygen Level,  %");
                    break;
                case "5":
                case "A8:1B:6A:AB:88:81":
                    sensorValueAdapter.addSensorValueObject(new SensorValue(), 1);
                    sv = sensorValueAdapter.getSensorValueObject(i++);
                    sv.setValueType1("Temperature,  'C");
                    sv.setValueType2("Humidity,  %");
                    sv.setValueType3("PM2.5,  ppm");
                    sv.setValueType4("UV Level,  level");
                    break;

                default:
                    Log.d("-DeviceActivity ", "BLE MAC UnAuth");
            }
        }

        RecyclerView sensorView = findViewById(R.id.sensor_value_list);
        sensorView.setAdapter(sensorValueAdapter);
        sensorView.setLayoutManager(new LinearLayoutManager(this));
        sensorView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        IntentFilter updateFilter = new IntentFilter();
        updateFilter.addAction("li.power.idsl.most.app.SENSOR_UPDATE");
        updateFilter.addAction("li.power.idsl.most.app.AUTH_UPDATE");
        broadcastReceiver = new SensorUpdateListener();
        registerReceiver(broadcastReceiver, updateFilter);
    }

    public class SensorUpdateListener extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, final Intent intent) {
            //final int sensorId = intent.getIntExtra("sensor",0);
            //final SensorValue sv = sensorValueAdapter.getSensorValueObject(sensorId);

            if (intent.getAction().equals("li.power.idsl.most.app.AUTH_UPDATE")) {
                runOnUiThread( new Runnable() {
                    @Override
                    public void run() {
                        int sensorId = intent.getIntExtra("sensor",0);
                        SensorValue sv = sensorValueAdapter.getSensorValueObject(sensorId);
                        sv.setAuthStatus(intent.getStringExtra("data"));
                        sensorValueAdapter.notifyDataSetChanged();
                    }
                });
            } else if (intent.getAction().equals("li.power.idsl.most.app.SENSOR_UPDATE")) {
                final int sensorId = intent.getIntExtra("sensor",0);
                final SensorValue sv = sensorValueAdapter.getSensorValueObject(sensorId);

                final String name = intent.getStringExtra("name");
                final String auth = intent.getStringExtra("auth");
                final float[] data = intent.getFloatArrayExtra("data");
                final Long time = intent.getLongExtra("time",0);

                sv.setName(name);
                sv.setAuthStatus(auth);
                sv.setAuthTime(time);

                if(data.length == 2) {
                    runOnUiThread( new Runnable() {
                        @Override
                        public void run() {
                            sv.setValue1(data[0]);
                            sv.setValue2(data[1]);
                            Log.d("-DeviceActivity id: " + sensorId + " data: ", data[0] + " / " + data[1]);

                            sensorValueAdapter.notifyDataSetChanged();
                        }
                    });
                }
                if (data.length == 4) {
                    runOnUiThread( new Runnable() {
                        @Override
                        public void run() {
                            sv.setValue1(data[0]);
                            sv.setValue2(data[1]);
                            sv.setValue3(data[2]);
                            sv.setValue4(data[3]);
                            Log.d("-DeviceActivity id: " + sensorId + " data: ", data[0] + " / " + data[1]
                                    + " / " + data[2]+ " / " + data[3]);

                            sensorValueAdapter.notifyDataSetChanged();
                        }
                    });
                }
            } else {
                Log.d("-DeviceActivity ", "BroadcastReceiver Mistake");
            }
            context.unregisterReceiver(this);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onDestroy() {
        try {
            if (broadcastReceiver != null)
                unregisterReceiver(broadcastReceiver);
        } catch (Exception e) {}
        super.onDestroy();
    }
}
