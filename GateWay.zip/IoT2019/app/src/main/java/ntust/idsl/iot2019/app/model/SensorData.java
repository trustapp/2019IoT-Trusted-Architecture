package ntust.idsl.iot2019.app.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "device_value")
public class SensorData {

    @DatabaseField(id = true,columnName = "ID")
    int id;

    @DatabaseField(columnName = "DeviceMAC")
    String deviceMAC;

    @DatabaseField(columnName = "AuthTime")
    int authTime;

    @DatabaseField(columnName = "SensorName")
    String sensorName;
    @DatabaseField(columnName = "SensorValue")
    float sensorValue;

    @DatabaseField(columnName = "reportid")
    String reportId="01122333-4556-6778-899a-abbccddeeff0";

    public SensorData(String deviceMAC, int authTime , String sensorName, float sensorValue) {
        this.deviceMAC = deviceMAC;
        this.authTime = authTime;
        this.sensorName = sensorName;
        this.sensorValue = sensorValue;
    }

    public SensorData(){}
}