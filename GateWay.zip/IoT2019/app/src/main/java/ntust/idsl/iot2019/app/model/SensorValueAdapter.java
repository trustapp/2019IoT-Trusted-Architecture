package ntust.idsl.iot2019.app.model;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import ntust.idsl.iot2019.R;

import java.util.ArrayList;
import java.util.List;

public class SensorValueAdapter extends RecyclerView.Adapter{

    private List<SensorValue> sensors = new ArrayList<>();
    private List<Integer> viewType = new ArrayList<>();

    private static final int TYPE_2_VALUE = 0;
    private static final int TYPE_4_VALUE = 1;

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v;
        if (viewType == TYPE_2_VALUE) {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.layout_sensor, parent, false);
            SensorDataViewHolder vh = new SensorDataViewHolder(v);
            return vh;
        }

        if(viewType == TYPE_4_VALUE) {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.layout_multi_sensor, parent, false);
            MultiSensorDataViewHolder vh = new MultiSensorDataViewHolder(v);
            return vh;
        }

        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof SensorDataViewHolder) {
            SensorDataViewHolder viewHolder = (SensorDataViewHolder) holder;
            SensorValue value = sensors.get(position);

            viewHolder.nameText.setText(value.getName());

            String[] str1 = new String(value.getValueType1()).split(",");
            String[] str2 = new String(value.getValueType2()).split(",");


            if (str1.length == 1) { // 先用str1代替所有，之後怕一斷線，最好用每個或兩個以上判斷
                viewHolder.valueText1.setText( String.format("%.2f",value.getValue1()) );
                viewHolder.valueText2.setText( String.format("%.2f",value.getValue2()) );

                viewHolder.authTimeText.setText( String.valueOf(value.getAuthTime()) );
            } else {
                viewHolder.valueText1.setText( String.format("%.2f",value.getValue1()) + str1[1] );
                viewHolder.valueText2.setText( String.format("%.2f",value.getValue2()) + str2[1] );

                viewHolder.authTimeText.setText( String.valueOf(value.getAuthTime()) + "  ms");
            }

            viewHolder.valueTypeText1.setText(str1[0]);
            viewHolder.valueTypeText2.setText(str2[0]);

            viewHolder.authStatusText.setText(value.getAuthStatus());
        }

        if (holder instanceof MultiSensorDataViewHolder) {
            MultiSensorDataViewHolder viewHolder = (MultiSensorDataViewHolder) holder;
            SensorValue value = sensors.get(position);

            viewHolder.nameText.setText(value.getName());

            String[] str1 = new String(value.getValueType1()).split(",");
            String[] str2 = new String(value.getValueType2()).split(",");
            String[] str3 = new String(value.getValueType3()).split(",");
            String[] str4 = new String(value.getValueType4()).split(",");

            if (str1.length == 1 || str2.length == 1 || str3.length == 1 || str4.length == 1) { // 先用str1代替所有，之後怕一斷線，最好用每個或兩個以上判斷
                viewHolder.valueText1.setText( String.format("%.2f",value.getValue1()) );
                viewHolder.valueText2.setText( String.format("%.2f",value.getValue2()) );
                viewHolder.valueText3.setText( String.format("%.2f",value.getValue3()) );
                viewHolder.valueText4.setText( String.format("%.2f",value.getValue4()) );

                viewHolder.authTimeText.setText( String.valueOf(value.getAuthTime()) );
            } else {
                viewHolder.valueText1.setText( String.format("%.2f",value.getValue1()) + str1[1] );
                viewHolder.valueText2.setText( String.format("%.2f",value.getValue2()) + str2[1] );
                viewHolder.valueText3.setText( String.format("%.2f",value.getValue3()) + str3[1] );
                viewHolder.valueText4.setText( String.format("%.2f",value.getValue4()) + str4[1] );

                viewHolder.authTimeText.setText( String.valueOf(value.getAuthTime()) + "  ms");
            }

            viewHolder.valueTypeText1.setText(str1[0]);
            viewHolder.valueTypeText2.setText(str2[0]);
            viewHolder.valueTypeText3.setText(str3[0]);
            viewHolder.valueTypeText4.setText(str4[0]);

            viewHolder.authStatusText.setText(value.getAuthStatus());
        }
    }

    @Override
    public int getItemCount() {
        return sensors.size();
    }


    class SensorDataViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        TextView authTimeText;
        TextView valueText1;
        TextView valueText2;
        TextView valueTypeText1;
        TextView valueTypeText2;
        TextView authStatusText;

        public SensorDataViewHolder(View itemView) {
            super(itemView); // need to call super constructor

            nameText =  itemView.findViewById(R.id.sensor_name);
            authTimeText = itemView.findViewById(R.id.sensor_auth_time);
            valueText1 = itemView.findViewById(R.id.sensor_value1);
            valueText2 = itemView.findViewById(R.id.sensor_value2);
            valueTypeText1 = itemView.findViewById(R.id.label_sensor_value1);
            valueTypeText2 = itemView.findViewById(R.id.label_sensor_value2);
            authStatusText = itemView.findViewById(R.id.sensor_auth);
        }
    }

    class MultiSensorDataViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        TextView authTimeText;
        TextView valueText1;
        TextView valueText2;
        TextView valueText3;
        TextView valueText4;
        TextView valueTypeText1;
        TextView valueTypeText2;
        TextView valueTypeText3;
        TextView valueTypeText4;
        TextView authStatusText;

        public MultiSensorDataViewHolder(View itemView) {
            super(itemView); // need to call super constructor

            nameText = itemView.findViewById(R.id.multi_sensor_name);
            authTimeText = itemView.findViewById(R.id.multi_sensor_auth_time);
            valueText1 = itemView.findViewById(R.id.multi_sensor_value1);
            valueText2 = itemView.findViewById(R.id.multi_sensor_value2);
            valueText3 = itemView.findViewById(R.id.multi_sensor_value3);
            valueText4 = itemView.findViewById(R.id.multi_sensor_value4);
            valueTypeText1 = itemView.findViewById(R.id.multi_label_sensor_value1);
            valueTypeText2 = itemView.findViewById(R.id.multi_label_sensor_value2);
            valueTypeText3 = itemView.findViewById(R.id.multi_label_sensor_value3);
            valueTypeText4 = itemView.findViewById(R.id.multi_label_sensor_value4);
            authStatusText = itemView.findViewById(R.id.multi_sensor_auth);
        }
    }

    public void addSensorValueObject (SensorValue value, int i) {
        sensors.add(value);
        viewType.add(i);
    }

    public SensorValue getSensorValueObject (int position) {
        return sensors.get(position);
    }

    @Override
    public int getItemViewType(int position) {
        if (viewType.get(position) == 0) {
            return TYPE_2_VALUE;
        } else {
            return TYPE_4_VALUE;
        }
    }
}
