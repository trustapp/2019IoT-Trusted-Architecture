package ntust.idsl.iot2019.algorithm;

import android.util.Log;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Random;
import ntust.idsl.iot2019.app.model.AuthTime;

public class Algorithm {

    private static final byte[] SK_SN = { (byte)0xaa, 0x56, 0x52, (byte)0x85, 0x6d, 0x59, 0x1a, (byte)0xbe
            , (byte)0x89, (byte)0xbd, (byte)0xf0, 0x43, (byte)0x8f, (byte)0xe5, 0x7f, 0x60, 0x16, 0x41, (byte)0xae, (byte)0xda };
    private static final byte[] SHA_SK_SN = { 0x3b, (byte)0xf5, 0x32, 0x7c, (byte)0xcf, (byte)0xe0, 0x2a, 0x67
            , (byte)0xe8, 0x6f, 0x41, (byte)0xc4, 0x5f, 0x59, (byte)0x0d, (byte)0xd1, (byte)0xa8, 0x4c, 0x5d, 0x55 };

    private int m; // Pass the "token" and the "m" to the next class
    private byte[] tksni; // 初始符記
    private boolean oneTime = false;
    private BigDecimal sysTime, delayTime;

    public Algorithm() {
        sysTime = new BigDecimal(System.currentTimeMillis());
    }

    private void toSQL (String status, double timer) {
        String databaseUrl = "jdbc:mysql://140.118.109.194:3306/iot_trust";

        try {
            ConnectionSource connectionSource = new JdbcConnectionSource(databaseUrl, "user", "user");
            Dao<AuthTime, String> sensorDataDao = DaoManager.createDao(connectionSource, AuthTime.class);

            sensorDataDao.create(new AuthTime(status, timer));
            Log.d("-TIMER", "toSQL timer:\t"+ timer);
            connectionSource.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int[] phase1 (String name, byte[] data) {
        int idsn = ((data[5] & 0xff) << 24) + ((data[4] & 0xff) << 16) + ((data[3] & 0xff) << 8) + (data[2] & 0xff); // [2] + [3]*2^8 +... 和會互相干擾
        int r1 = ((data[9] & 0xff) << 24) + ((data[8] & 0xff) << 16) + ((data[7] & 0xff) << 8) + (data[6] & 0xff);

        byte[] mt = Arrays.copyOfRange(data, 10, 30); // index 10-29
        byte[]  x = Arrays.copyOfRange(data, 30, 50);
        byte[] m1 = Arrays.copyOfRange(data, 50, 70);
        byte[] m2 = Arrays.copyOfRange(data, 70, 90); // 最後兩位 46

        Log.d(name + "-AUTH", "idsn:\t" + idsn);
        Log.d(name + "-AUTH", "r1:\t" + r1);
        Log.d(name + "-AUTH", "mt:\t" + Hash.bytesToHex(mt));
        Log.d(name + "-AUTH", "x:\t" + Hash.bytesToHex(x)); // ex. A2BC69
        Log.d(name + "-AUTH", "m1s:\t" + Hash.bytesToHex(m1));
        Log.d(name + "-AUTH", "m2s:\t" + Hash.bytesToHex(m2));

        byte[] m2p = Hash.getHmac(SK_SN, idsn, x, m1, r1, mt);
        Log.d(name + "-AUTH", "m2p:\t" + Hash.bytesToHex(m2p));
        if (!Hash.compareByteArray(m2, m2p)) {
            Log.d(name + "-AUTH", "m2 mismatch");
            return null; // 回傳判斷 !!!!!
        }

        byte[] mbp = Hash.getSHA(Hash.getXorWithSHA(SK_SN, r1));
        Log.d(name + "-AUTH", "mtp:\t" + Hash.bytesToHex(mbp));

        int rb = Hash.getSubSHA(mt) ^ Hash.getSubSHA(mbp);
        Log.d(name + "-AUTH", "ts:\t" + String.valueOf(rb)); // > tssn = rb <

        byte[] rbHash = Hash.getSHA(rb);
        int v = Hash.getSubSHA(rbHash) ^ Hash.getSubSHA(x);

        byte[] m1p = Hash.getSHA(Hash.getXorWithSHA(SHA_SK_SN, (idsn | v)));
        Log.d(name + "-AUTH", "m1p:\t" + Hash.bytesToHex(m1p));

        if (!Hash.compareByteArray(m1, m1p)) {
            Log.d(name + "-AUTH", "m1 mismatch");
            return null;
        }

        if (!oneTime) {
            sysTime = new BigDecimal(System.currentTimeMillis());
            delayTime = sysTime.subtract(new BigDecimal(rb*1000d));
            oneTime = true;
            Log.d("-TIMER", "delayTime:\t" + delayTime);
        }

        int[] result = new int[3];
        result[0] = idsn;
        result[1] = v;
        result[2] = r1;

        Log.d(name + "-AUTH", " phase1 successful return");
        return result;
    }

    public byte[] phase2 (String name, int idsn, int v, int r1) {
        Random random = new Random();
        int w = 0x01000000 + random.nextInt(0x0fffffff); // return 0 ~ @par-1
        int n1 = 0x01000000 + random.nextInt(0x0fffffff);
        Log.d(name + "-AUTH", " w:\t" + String.valueOf(w));

        byte[] y = Hash.getXorWithSHA(Hash.getSHA(Hash.getXorWithSHA(SK_SN, n1)), w);
        Log.d(name + "-AUTH", " y:\t" + Hash.bytesToHex(y));

        tksni = Hash.getSHA(Hash.getXorWithSHA(SK_SN, v ^ w));
        Log.d(name + "-AUTH", " tksni:\t" + Hash.bytesToHex(tksni));

        byte[] m3 = Hash.getSHA(Hash.getXorWithSHA(SHA_SK_SN, Hash.getSubSHA(tksni) | idsn));
        Log.d(name + "-AUTH", " m3:\t" + Hash.bytesToHex(m3));

        byte[] m4 = Hash.getHmac(SK_SN, n1, r1, y, m3);
        Log.d(name + "-AUTH", " m4:\t" + Hash.bytesToHex(m4));

        Log.d(name + "-AUTH", " w:\t" + w);
        m = w;
        Log.d(name + "-AUTH", " m:\t" + m);

        byte[] toSensor = new byte[66];
        byte[] n1Bytes = ByteBuffer.allocate(4).putInt(n1).array();

        toSensor[0] = (byte) 0x66;
        toSensor[1] = (byte) 0x99;

        for (int i = 0; i < 20; i++) { //uin8_t size 20
            toSensor[i + 2] = m3[i];
            toSensor[i + 20 + 2] = m4[i];
            toSensor[i + 40 + 2] = y[i];
        }
        for (int i = 0; i < 4; i++) {
            toSensor[i + 60 + 2] = n1Bytes[i];
        }

        Log.d(name + "-AUTH", " (m) phase2 successful return");
        return toSensor;
    }

    public byte[] contPhase (String name, byte[] data, boolean entStatic) {
        int idsn = ((data[5] & 0xff) << 24) + ((data[4] & 0xff) << 16) + ((data[3] & 0xff) << 8) + (data[2] & 0xff);
        int r2 = ((data[9] & 0xff) << 24) + ((data[8] & 0xff) << 16) + ((data[7] & 0xff) << 8) + (data[6] & 0xff);

        byte[] mt = Arrays.copyOfRange(data, 10, 30);
        byte[] ms = Arrays.copyOfRange(data, 30, 50);
        byte[] m5 = Arrays.copyOfRange(data, 50, 70);

        Log.d(name + "-AUTH", "idsn:\t" + idsn);
        Log.d(name + "-AUTH", "r2:\t" + r2);
        Log.d(name + "-AUTH", "mt:\t" + Hash.bytesToHex(mt));
        Log.d(name + "-AUTH", "ms:\t" + Hash.bytesToHex(ms));
        Log.d(name + "-AUTH", "m5:\t" + Hash.bytesToHex(m5));
        Log.d(name + "-AUTH", "tksni:\t" + Hash.bytesToHex(tksni));

        int tc_snp; // fine, this parameter everyone wants it
        byte[] y1, ack; // These two are also popular

        if (entStatic) { // 下一筆換靜態
            Log.d(name + "-AUTH", " Next phase static authentication");

            byte[] ts = ByteBuffer.allocate(4).putInt(Hash.getSubSHA(tksni)).array();
            byte[] mr2 = ByteBuffer.allocate(4).putInt(m ^ r2).array();
            for (int i = 0; i < 4; i++)
                ts[i] = (byte) (ts[i] | mr2[i]);
            byte[] tc_tmp = Hash.getSHA(ts);
            Log.d(name + "-AUTH", "(m^r2):\t" + (m ^ r2));
            Log.d(name + "-AUTH", "tk_sni(HEX):\t" + Hash.bytesToHex(tksni));
            Log.d(name + "-AUTH", "Hash.getSubSHA(ts|m^r2):\t" + Hash.bytesToHex(ts));
            Log.d(name + "-AUTH", "H(tk_sni|(m^r2)):\t" + Hash.bytesToHex(tc_tmp));

            tc_snp = Hash.getSubSHA(tc_tmp) ^ Hash.getSubSHA(mt);
            Log.d(name + "-AUTH", "ts:\t" + tc_snp); // > tcsn = tc_snp <

            sysTime = new BigDecimal(System.currentTimeMillis());
            Log.d(name + "-TIMER", "sysTime:\t" + sysTime);
            Log.d(name + "-TIMER", "(tc_snp + delayTime):\t" + delayTime.add(new BigDecimal(tc_snp*1000d)));
            toSQL(name, sysTime.subtract(delayTime.add(new BigDecimal(tc_snp*1000d))).doubleValue());

//            if ( abs > 3) {
//                Log.d(name + "-TIMER", "Math.abs:\t" + abs);
//                return null;
//            }

            byte[] y1_temp1 = Hash.getXorWithSHA(tksni, r2);
            int y1_temp1p = Hash.getSubSHA(y1_temp1);
            byte[] tcr2 = ByteBuffer.allocate(4).putInt(y1_temp1p).array();
            Log.d(name + "-AUTH", "Hash.getSubSHA(tk_sni^r2):\t" + Hash.bytesToHex(tcr2));
            Log.d(name + "-AUTH", "m:\t" + m);

            byte[] m_temp = ByteBuffer.allocate(4).putInt(m).array();
            for (int i = 0; i < 4; i++)
                tcr2[i] = (byte) (tcr2[i] | m_temp[i]);
            Log.d(name + "-AUTH", "(tk_sni^r2)|m:\t" + Hash.bytesToHex(tcr2));

            byte[] pre_y = Hash.getSHA(tcr2);
            Log.d(name + "-AUTH", "H((tk_sni^r2)|m):\t" + Hash.bytesToHex(pre_y));

            int y1_temp4 = m | Hash.getSubSHA(tksni);
            Log.d(name + "-AUTH", "m|tk:\t" + y1_temp4);

            y1 = Hash.getXorWithSHA(pre_y, y1_temp4);
            Log.d(name + "-AUTH", "y1:\t" + Hash.bytesToHex(y1));

            byte[] piyan = ByteBuffer.allocate(4).putInt(m ^ tc_snp).array();
            byte[] gunmon = ByteBuffer.allocate(4).putInt(tc_snp ^ r2).array();
            byte[] maryan = ByteBuffer.allocate(4).putInt(m | Hash.getSubSHA(tksni)).array();
            for (int i = 0; i < 4; i++) {
                piyan[i] = (byte) (piyan[i] | gunmon[i] | maryan[i]);
            }
            ack = Hash.getSHA(piyan);
            Log.d(name + "-AUTH", "ack:\t" + Hash.bytesToHex(ack));

        } else {  // 下一筆還是跑連續
            Log.d(name + "-AUTH", " Next phase Continuous authentication");

            byte[] ts = ByteBuffer.allocate(4).putInt(Hash.getSubSHA(tksni)).array();
            byte[] mr2 = ByteBuffer.allocate(4).putInt(m ^ r2).array();
            for (int i = 0; i < 4; i++)
                ts[i] = (byte) (ts[i] | mr2[i]);

            byte[] tc_tmp = Hash.getSHA(ts);
            Log.d(name + "-AUTH", "(m^r2):\t" + (m ^ r2));
            Log.d(name + "-AUTH", "tk_sni(HEX):\t" + Hash.bytesToHex(tksni));
            Log.d(name + "-AUTH", "Hash.getSubSHA(ts|m^r2):\t" + Hash.bytesToHex(ts));
            Log.d(name + "-AUTH", "H(tk_sni|(m^r2)):\t" + Hash.bytesToHex(tc_tmp));

            tc_snp = Hash.getSubSHA(tc_tmp) ^ Hash.getSubSHA(mt);
            Log.d(name + "-AUTH", "tc:\t" + tc_snp);

            sysTime = new BigDecimal(System.currentTimeMillis());
            Log.d(name + "-TIMER", "sysTime:\t" + sysTime);
            Log.d(name + "-TIMER", "(tc_snp + delayTime):\t" + delayTime.add(new BigDecimal(tc_snp*1000d)));
            toSQL(name, sysTime.subtract(delayTime.add(new BigDecimal(tc_snp*1000d))).doubleValue());

//            if ( abs > 3) {
//                Log.d(name + "-TIMER", "Math.abs:\t" + abs);
//                return null;
//            }

            // generate sdp, though it wasn't used by the way.
            byte[] sdp_tmp1 = Hash.getXorWithSHA(tksni, m);
            byte[] sdp_tmp2 = Hash.getSHA(Hash.getSubSHA(sdp_tmp1) | r2);
            byte[] sdp = Hash.getXorWithSHA(sdp_tmp2, Hash.getSubSHA(ms));
            Log.d(name + "-AUTH", "sd':\t" + Hash.bytesToHex(sdp));

            byte[] m5p = Hash.getHmac(SK_SN, idsn, ms, mt, r2);
            Log.d(name + "-AUTH", "m5p:\t" + Hash.bytesToHex(m5p));
            if (!Hash.compareByteArray(m5, m5p)) {
                Log.d(name + "-AUTH", "m5 mismatch");
                return null;
            }

            Random random = new Random();
            int n2 = 0x01000000 + random.nextInt(0x0fffffff);
            byte[] y1_temp1 = Hash.getXorWithSHA(tksni, r2);
            int y1_temp1p = Hash.getSubSHA(y1_temp1);
            byte[] tcr2 = ByteBuffer.allocate(4).putInt(y1_temp1p).array();

            Log.d(name + "-AUTH", "Hash.getSubSHA(tk_sni^r2):\t" + Hash.bytesToHex(tcr2));
            Log.d(name + "-AUTH", "m:\t" + m);

            byte[] m_temp = ByteBuffer.allocate(4).putInt(m).array();
            for (int i = 0; i < 4; i++)
                tcr2[i] = (byte) (tcr2[i] | m_temp[i]);
            Log.d(name + "-AUTH", "(tk_sni^r2)|m:\t" + Hash.bytesToHex(tcr2));

            byte[] pre_y = Hash.getSHA(tcr2);
            Log.d(name + "-AUTH", "H((tk_sni^r2)|m):\t" + Hash.bytesToHex(pre_y));

            y1 = Hash.getXorWithSHA(pre_y, n2);
            Log.d(name + "-AUTH", "y1:\t" + Hash.bytesToHex(y1));

            byte[] piyan = ByteBuffer.allocate(4).putInt(m ^ tc_snp).array();
            byte[] gunmon = ByteBuffer.allocate(4).putInt(n2 ^ r2).array();
            byte[] maryan = ByteBuffer.allocate(4).putInt(m ^ Hash.getSubSHA(tksni)).array();
            for (int i = 0; i < 4; i++) {
                piyan[i] = (byte) (piyan[i] | gunmon[i] | maryan[i]);

            }
            Log.d(name + "-AUTH", "piyan[]:\t" + piyan[0] + piyan[1] + piyan[2] + piyan[3]);

            ack = Hash.getSHA(piyan);
            Log.d(name + "-AUTH", "ack:\t" + Hash.bytesToHex(ack));

            m = n2;
            Log.d(name + "-AUTH", "n2:\t" + m);
        }

        byte[] toSensor = new byte[42];
        toSensor[0] = 0x66;
        toSensor[1] = (byte) 0x99;
        for (int i = 0; i < 20; i++) {
            toSensor[2 + i] = y1[i];
            toSensor[2 + 20 + i] = ack[i];
        }
        return toSensor;
    }

    public int getM() {
        return m;
    }

    public byte[] getTksni() {
        return tksni;
    }
}
