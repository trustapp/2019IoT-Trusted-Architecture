package ntust.idsl.iot2019.app.model;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import ntust.idsl.iot2019.R;

import java.util.ArrayList;

public class BLEDeviceAdapterRe extends RecyclerView.Adapter {

    private ArrayList<BLEDevice> bleDevices;
    private int position;
    private Context context;

    public BLEDeviceAdapterRe (Context context, ArrayList<BLEDevice> bleDevices) {
        this.context = context;
        this.bleDevices = bleDevices;
    }

    public int getPosition() {
        return position;
    }
    private void setPosition (int position) {
        this.position = position;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder (ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.ble_device_item, parent, false);
        BLEDeviceViewHolder vh = new BLEDeviceViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder (final RecyclerView.ViewHolder holder, final int position) {
        BLEDeviceViewHolder bdHolder = (BLEDeviceViewHolder) holder;
        bdHolder.nameText.setText(bleDevices.get(position).getName());
        bdHolder.addressText.setText(bleDevices.get(position).getAddress());
        this.position = position;
        bdHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                setPosition(holder.getAdapterPosition());
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return bleDevices.size();
    }

    public String getAddressAtPosition (int position) {
        return bleDevices.get(position).getAddress();
    }

    class BLEDeviceViewHolder extends RecyclerView.ViewHolder {
        public TextView nameText;
        public TextView addressText;

        public BLEDeviceViewHolder (View v) {
            super(v);
            nameText = v.findViewById(R.id.device_name);
            addressText = v.findViewById(R.id.device_address);
        }
    }

    public void add (BLEDevice item) {
        for (BLEDevice d : bleDevices) {
            if (d.getAddress().equals(item.getAddress())) {
                // d.setRssi(item.getRssi());
                return;
            }
        }
        this.bleDevices.add(item);
    }


    public BLEDevice get(int i) {
        return bleDevices.get(i);
    }

    public BLEDevice getDeviceByName (String name) {
        for (BLEDevice d:bleDevices) {
            if (d.getName().equals(name))
                return d;
        }
        return null;
    }

    public void clear() {
        this.bleDevices.clear();
    }
}
