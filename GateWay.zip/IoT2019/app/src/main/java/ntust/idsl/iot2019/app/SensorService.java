package ntust.idsl.iot2019.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import java.util.ArrayList;

public class SensorService extends Service {

    private static SensorService instance;
    private static SensorService getInstance() {
        return instance;
    }

    private ArrayList<Sensor> sensors;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        instance = this;
        sensors = new ArrayList<>();

        Bundle args = intent.getBundleExtra("Bundle");
        ArrayList<BluetoothDevice> mBleDevices = (ArrayList<BluetoothDevice>) args.getSerializable("devices");

        Log.d("-size before",mBleDevices.size() + "");
        int j = 0;
        for (int i = 0; i < mBleDevices.size(); i++) {
            switch (mBleDevices.get(i).getAddress()) {
                case "1":
                case "18:62:E4:3D:ED:28":
                case "3":
                case "4":
                case "5":
                case "A8:1B:6A:AB:88:81":
                    sensors.add( new Sensor(mBleDevices.get(i), getApplicationContext(), j++) );
                    break;

                default:
                    mBleDevices.remove(i--);
            }
        }
        Log.d("-size after",mBleDevices.size() + "");

        NotificationManager notificationManger = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        intent = new Intent();
        intent.setClass(this, DeviceActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0, intent,0);

        Notification notification = new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .setContentTitle("Sensor Service")
                .setContentText("Service is now running...")
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
        notification.flags = Notification.FLAG_NO_CLEAR;
        notificationManger.notify(1, notification);
        startForeground(1, notification);

        scanLeDevice();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void scanLeDevice () {
        try {
            scanStartThread.start();
            //reConnectThread.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Thread scanStartThread = new Thread ( new Runnable() {
        @Override
        public void run() {
            for (int i = sensors.size() - 1; i >= 0; i--) {
                    Log.d("-scanStartThread ", "id " + i + " start to auth.");
                    sensors.get(i).start();

                    while(!sensors.get(i).boo_canStartNext) {
                        try {
                            //Log.d("-scanLeDevice ", "id " + i + " connecting");
                            Thread.sleep(200);
                        } catch (Exception e) {}
                    }
            }
            Log.d("-scanStartThread ", "all devices connection finished");
        }
    });
}
