package ntust.idsl.iot2019.app;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.util.Arrays;
import ntust.idsl.iot2019.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(R.string.app_title);

        BluetoothAdapter mBluetoothAdapter = ((BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();

        if (mBluetoothAdapter == null) {
            Log.d("-MainActivity ", "No support BT");
            onDestroy();
        } else if (!mBluetoothAdapter.isEnabled()) {
            Log.d("-MainActivity ", "Open BT");
            mBluetoothAdapter.enable();
        } else {
            Log.d("-MainActivity ", "BT Opened");
        }

        requestPermission(this);
    }

    private void requestPermission (MainActivity activity) {
        int j = 0;
        String[] permissions = new String[] { Manifest.permission.ACCESS_FINE_LOCATION // dangerous permission
                , Manifest.permission.READ_EXTERNAL_STORAGE };

        for (int i = 0; i < permissions.length; i++) {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), permissions[i]) != PackageManager.PERMISSION_GRANTED) {
                permissions[j++] = permissions[i];
            }
        }

        if (j > 0) {
            ActivityCompat.requestPermissions(activity, Arrays.copyOf(permissions, j), 1);
        } else {
            startService(new Intent().setClass(this, SensorService.class));
            Intent i = new Intent(getApplicationContext(), ScanActivity.class);
            startActivity(i);
            //finish();
        }
    }

    @Override
    public void onRequestPermissionsResult (int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1: {
                Log.d("-MainActivity ", "grantResults.length:" + grantResults.length);
                if (grantResults.length > 0) {
                    for (int result : grantResults) {
                        if (result != PackageManager.PERMISSION_GRANTED) {
                            Log.d("-MainActivity ", "Bye");
                            onDestroy();
                        }
                    }
                    Intent i = new Intent(getApplicationContext(), ScanActivity.class);
                    startActivity(i);
                    //finish();
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        System.exit(0);
    }
}

