package ntust.idsl.iot2019.app.model;

import android.bluetooth.BluetoothDevice;

public class BLEDevice {

    private String name;
    private String address;
    private BluetoothDevice device;

    public BLEDevice(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public BluetoothDevice getDevice() {
        return device;
    }


}
