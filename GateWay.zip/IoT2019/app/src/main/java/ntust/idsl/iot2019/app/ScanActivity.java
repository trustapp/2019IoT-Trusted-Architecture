package ntust.idsl.iot2019.app;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import ntust.idsl.iot2019.app.model.BLEDevice;
import ntust.idsl.iot2019.app.model.BLEDeviceAdapterRe;
import ntust.idsl.iot2019.R;

public class ScanActivity extends Activity {

    private final int REQUEST_ENABLE_BT = 2;

    private Button mbleConnect;
    private RecyclerView mscanList;

    private BluetoothAdapter mbluetoothAdapter;
    private BluetoothLeScanner mbluetoothLeScanner;

    private ArrayList<BLEDevice> mBleDevices = new ArrayList<>();
    private ArrayList<BluetoothDevice> mBleDevicesCheck = new ArrayList<>();

    private ArrayList<String> selectedMacs = new ArrayList<>();
    private ArrayList<BluetoothDevice> selectedDevices = new ArrayList<>();

    private BLEDeviceAdapterRe scanListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        mbleConnect = findViewById(R.id.bleConnect);
        mscanList = findViewById(R.id.scanList);

        scanListAdapter = new BLEDeviceAdapterRe(this, mBleDevices);
        mscanList.setAdapter(scanListAdapter);
        mscanList.setLayoutManager(new LinearLayoutManager(this));
        mscanList.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        registerForContextMenu(mscanList);
        mscanList.setAdapter(scanListAdapter);
        mscanList.setOnLongClickListener ( new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                return false;
            }
        });

        mbluetoothAdapter = ((BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();
        mbluetoothLeScanner = mbluetoothAdapter.getBluetoothLeScanner();
        mbluetoothLeScanner.startScan(mscanCallback);

        mbleConnect.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mbluetoothLeScanner.stopScan(mscanCallback);
                Intent serviceIntent = new Intent();
                Bundle args = new Bundle();
                serviceIntent.setClass(ScanActivity.this, SensorService.class);
                args.putSerializable("devices", selectedDevices);
                serviceIntent.putExtra("Bundle", args);
                startService(serviceIntent);

                Intent connectIntent = new Intent();
                connectIntent.setClass(ScanActivity.this, DeviceActivity.class);
                connectIntent.putStringArrayListExtra("devices", selectedMacs);
                startActivity(connectIntent);
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mbluetoothAdapter == null || !mbluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0,0,0,"選擇");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int position = scanListAdapter.getPosition();
        selectedMacs.add(mBleDevices.get(position).getAddress());
        selectedDevices.add(mBleDevicesCheck.get(position));
        Toast.makeText(this, "Select device:" + mBleDevices.get(position).getAddress(), Toast.LENGTH_SHORT).show();
        return super.onContextItemSelected(item);
    }

    private class onItemLongClickListener implements AdapterView.OnItemLongClickListener {
        @Override
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
            return false;
        }
    }

    private ScanCallback mscanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            BluetoothDevice scanDevice = result.getDevice();

            if (scanDevice.getName() != null && (!mBleDevicesCheck.contains(scanDevice))) {
                mBleDevicesCheck.add(result.getDevice());
                mBleDevices.add( new BLEDevice(result.getDevice().getName(), result.getDevice().getAddress() ));
                scanListAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onBatchScanResults (List<ScanResult> results) {
            super.onBatchScanResults(results);
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            Toast.makeText(ScanActivity.this, "onScanFailed: " + String.valueOf(errorCode),
                    Toast.LENGTH_LONG).show();
        }
    };
}

