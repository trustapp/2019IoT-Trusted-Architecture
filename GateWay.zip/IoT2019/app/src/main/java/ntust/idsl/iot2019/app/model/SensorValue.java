package ntust.idsl.iot2019.app.model;

public class SensorValue {

    private String name="null";
    private long authTime = 0;
    private float value1 = 0, value2 = 0, value3 = 0, value4 = 0;
    private String valueType1 = "Sensor Data: ";
    private String valueType2 = "Sensor Data: ";
    private String valueType3 = "Sensor Data: ";
    private String valueType4 = "Sensor Data: ";
    private String authStatus = "no connect";

    public void setName(String name) {
        this.name = name;
    }

    public void setAuthTime(long authTime) {
        this.authTime = authTime;
    }

    public void setValue1(float value1) {
        this.value1 = value1;
    }

    public void setValue2(float value2) {
        this.value2 = value2;
    }

    public void setValue3(float value3) { this.value3 = value3; }

    public void setValue4(float value4) {
        this.value4 = value4;
    }

    public void setValueType1(String valueType1) {
        this.valueType1 = "Sensor Data: "+valueType1;
    }

    public void setValueType2(String valueType2) {
        this.valueType2 = "Sensor Data: "+valueType2;
    }

    public void setValueType3(String valueType3) {
        this.valueType3 = "Sensor Data: "+valueType3;
    }

    public void setValueType4(String valueType4) {
        this.valueType4 = "Sensor Data: "+valueType4;
    }

    public void setAuthStatus(String authStatus) {
        this.authStatus = authStatus;
    }

    public String getName() {
        return name;
    }

    public long getAuthTime() {
        return authTime;
    }

    public float getValue1() {
        return value1;
    }

    public float getValue2() {
        return value2;
    }

    public float getValue3() {
        return value3;
    }

    public float getValue4() {
        return value4;
    }

    public String getValueType1() {
        return valueType1;
    }

    public String getValueType2() {
        return valueType2;
    }

    public String getValueType3() {
        return valueType3;
    }

    public String getValueType4() {
        return valueType4;
    }

    public String getAuthStatus() {
        return authStatus;
    }

}
