package com.example.zxa01.iotclient.component.home;

import android.databinding.BaseObservable;

public class HomeModel extends BaseObservable {

    public HomeModel() {

    }
}
