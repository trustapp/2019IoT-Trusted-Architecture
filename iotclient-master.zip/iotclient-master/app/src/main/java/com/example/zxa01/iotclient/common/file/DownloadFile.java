package com.example.zxa01.iotclient.common.file;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.widget.Toast;

import com.example.zxa01.iotclient.R;
import com.example.zxa01.iotclient.common.notification.NotificationService;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import static android.support.v4.app.ActivityCompat.requestPermissions;

public class DownloadFile {

    private static final String TAG = "Download File";
    private Context context;
    private String downloadUrl;
    private String downloadFileName;

    private AlertDialog dialog;


    public DownloadFile(Context context, String downloadUrl) {
        this.context = context;
        this.downloadUrl = downloadUrl;
        this.dialog = new AlertDialog.Builder(context)
                .setMessage(R.string.privacy_loading_message)
                .setTitle(R.string.detail_report_download)
                .create();
        isStoragePermissionGranted();
        new DownloadingTask().execute();
    }

    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (context.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                requestPermissions((Activity) context,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        } else {
            return true;
        }
    }

    private void dialogDelay() {
        new Handler().postDelayed(() -> {
        }, 3000);
    }

    private void notification() {
        new NotificationService(context, "下載成功", downloadFileName,new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                .build();
    }

    private class DownloadingTask extends AsyncTask<Void, Void, Void> {

        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog.show();
        }


        @Override
        protected void onPostExecute(Void result) {
            try {
                dialog.hide();
                if (outputFile != null) {
                    notification();
                    Toast.makeText(context, "Downloaded Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    dialogDelay();
                    Toast.makeText(context, "Downloaded Failed", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                dialogDelay();
                Toast.makeText(context, "Downloaded Failed with Exception", Toast.LENGTH_SHORT).show();
            }
            super.onPostExecute(result);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                URL url = new URL(downloadUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();

                downloadFileName = java.net.URLDecoder.decode(
                        connection.getHeaderField("Content-Disposition")
                                .substring(connection.getHeaderField("Content-Disposition").indexOf("=") + 1)
                                .replace("UTF-8''", "")
                                .trim(),
                        String.valueOf(StandardCharsets.UTF_8));

                // check SDCard
                if (!new CheckForSDCard().isSDCardPresent()) {
                    Toast.makeText(context, "There is no SD Card.", Toast.LENGTH_SHORT).show();
                }

                // check file
                outputFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), downloadFileName);
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                    outputFile.setWritable(true);
                    Log.e(TAG, "File Created");
                }

                // output handle
                FileOutputStream fos = new FileOutputStream(outputFile);

                InputStream input = new BufferedInputStream(url.openStream(), 8192);
                OutputStream output = new FileOutputStream(outputFile.getPath());
                byte[] data = new byte[1024];
                long total = 0;
                int count;
                while ((count = input.read(data)) != -1) {
                    total += count;
                    output.write(data, 0, count);
                }
                fos.flush();
                fos.close();
                input.close();

            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
                Log.e(TAG, "Download Error Exception " + e.getMessage());
            }
            return null;
        }
    }

    class CheckForSDCard {
        public boolean isSDCardPresent() {
            if (Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                return true;
            }
            return false;
        }

    }

}