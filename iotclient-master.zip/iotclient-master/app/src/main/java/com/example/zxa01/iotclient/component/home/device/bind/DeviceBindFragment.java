package com.example.zxa01.iotclient.component.home.device.bind;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.zxa01.iotclient.R;
import com.example.zxa01.iotclient.databinding.FragmentDeviceBindBinding;

public class DeviceBindFragment extends DialogFragment {

    public DeviceBindViewModel viewModel;
    public FragmentDeviceBindBinding binding;

    public DeviceBindFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_device_bind, container, false);
        binding();
        init();
        return binding.getRoot();
    }

    private void binding() {
        viewModel = new DeviceBindViewModel(this);
        binding.setViewModel(viewModel);
    }

    private void init(){
        viewModel.observeIsLoadingMLD().observe(this,viewModel::setIsUpload);
    }


}
