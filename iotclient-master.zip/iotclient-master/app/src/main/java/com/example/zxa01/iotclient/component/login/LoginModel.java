package com.example.zxa01.iotclient.component.login;

import com.example.zxa01.iotclient.common.pojo.Setting;
import com.example.zxa01.iotclient.common.user.Config;
import com.example.zxa01.iotclient.common.pojo.auth.LoginMessage;
import com.example.zxa01.iotclient.common.user.DefaultData;
import com.example.zxa01.iotclient.common.user.KeyGenerate;
import com.example.zxa01.iotclient.common.user.UsersProvider;

import android.arch.lifecycle.MutableLiveData;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.databinding.BaseObservable;
import android.support.annotation.NonNull;

import java.security.NoSuchAlgorithmException;

public class LoginModel extends BaseObservable {

    private MutableLiveData<Boolean> isAuthorized;
    private Context context;

    public LoginModel(Context context) {
        this.context = context;
        isAuthorized = new MutableLiveData<>();
        isAuthorized.setValue(false);
    }

    public MutableLiveData<Boolean> isAuthorized() {
        return isAuthorized;
    }

    public void login(@NonNull LoginMessage message) {

        if (verification(message)) {
            settingConfig(message);
            isAuthorized.setValue(true);
            checkKey();
        }

    }

    private void checkKey() {
        Cursor cursor = context.getContentResolver().query(
                UsersProvider.CONTENT_URI, null, null, null, null);
        if(cursor.moveToFirst()) {
            boolean found = false;
            while (!cursor.isAfterLast()) {
                if(cursor.getString(cursor.getColumnIndex(UsersProvider.name)).equals(Config.getConfig().getMessage().getAccount())){
                    Config.getConfig().setKey(cursor.getString(cursor.getColumnIndex(UsersProvider.secret_key)));
                    found = true;
                    break;
                }
                cursor.moveToNext();
            }
            if (!found) {
                generateKey();
            }
        } else{
            generateKey();
        }

    }

    private void generateKey() {
        try {
            Config.getConfig().setKey(new KeyGenerate().generate());
            ContentValues values = new ContentValues();
            values.put(UsersProvider.name,Config.getConfig().getMessage().getAccount());
            values.put(UsersProvider.secret_key,Config.getConfig().getKey());
            context.getContentResolver().insert(UsersProvider.CONTENT_URI, values);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    private boolean verification(@NonNull LoginMessage message) {
        return message.getAccount() != null &&
                message.getPassword() != null &&
                message.getAddress() != null;
    }

    private void settingConfig(@NonNull LoginMessage message) {
        Config.getConfig().setMessage(new LoginMessage(
                message.getAddress(),
                DefaultData.getDefaultData().gatewayPort,
                DefaultData.getDefaultData().cloudPort,
                message.getAccount(),
                null
        ));
        Config.getConfig().addSetting(new Setting().setKey(Config.USER).setValue(Config.getConfig().getMessage().getAccount()));
        Config.getConfig().addSetting(new Setting().setKey(Config.ADDRESS).setValue(Config.getConfig().getMessage().getAddress()));
        Config.getConfig().addSetting(new Setting().setKey(Config.LOGOUT).setValue(Config.LOGOUT_MESSAGE));
    }

}
