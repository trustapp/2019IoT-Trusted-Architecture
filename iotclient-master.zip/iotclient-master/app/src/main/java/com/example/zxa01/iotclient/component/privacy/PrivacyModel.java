package com.example.zxa01.iotclient.component.privacy;

import android.arch.lifecycle.MutableLiveData;
import android.databinding.BaseObservable;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Log;

import com.example.zxa01.iotclient.common.pojo.auth.User;
import com.example.zxa01.iotclient.common.pojo.index.PrivacyPolicyReportResponse;
import com.example.zxa01.iotclient.common.http.Api;
import com.example.zxa01.iotclient.common.pojo.index.PrivacyChoiceResponse;
import com.example.zxa01.iotclient.common.pojo.privacy.PrivacyChoice;
import com.example.zxa01.iotclient.common.pojo.privacy.PrivacyContent;
import com.example.zxa01.iotclient.common.user.Config;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PrivacyModel extends BaseObservable {

    private MutableLiveData<PrivacyPolicyReportResponse> privacyPolicyReportMLD = new MutableLiveData<>();
    private MutableLiveData<Boolean> isUploadMLD = new MutableLiveData<>();

    public PrivacyModel() {
        privacyPolicyReportMLD.setValue(new PrivacyPolicyReportResponse());
        isUploadMLD.setValue(false);
    }

    public MutableLiveData<PrivacyPolicyReportResponse> getPrivacyPolicyReportMLD() {
        return privacyPolicyReportMLD;
    }

    public MutableLiveData<Boolean> getIsUploadMLD() {
        return isUploadMLD;
    }

    public void readPrivacyPolicyReportByDevice(@NonNull String udn) {
        Api.getApi().readPrivacyPolicyReportByDevice(udn,Config.getConfig().getMessage().getAccount()).enqueue(new Callback<PrivacyPolicyReportResponse>() {
            @Override
            public void onResponse(Call<PrivacyPolicyReportResponse> call, Response<PrivacyPolicyReportResponse> response) {
                privacyPolicyReportMLD.setValue(response.body());
            }

            @Override
            public void onFailure(Call<PrivacyPolicyReportResponse> call, Throwable t) {
                Log.e("readPrivacyPolicyReportByDevice - onFailure()", t.getMessage(), t);
            }
        });
    }

    public void setPrivacyChoice(@NonNull PrivacyContent privacyContent, @NonNull boolean isAccepted) {
        isUploadMLD.setValue(true);
        Api.getApi().setPrivacyChoice(new PrivacyChoice()
                .setPrivacyContent(
                        privacyContent.setUser(new User().setAccount(Config.getConfig().getMessage().getAccount())))
                .setAccepted(isAccepted))
                .enqueue(new Callback<PrivacyChoiceResponse>() {
                    @Override
                    public void onResponse(Call<PrivacyChoiceResponse> call, Response<PrivacyChoiceResponse> response) {
                        Log.i("setPrivacyChoice - onResponse()", "success");
                        readPrivacyPolicyReportByDevice(privacyContent.getDevice().getUdn());
                        dialogDelay();
                    }

                    @Override
                    public void onFailure(Call<PrivacyChoiceResponse> call, Throwable t) {
                        Log.e("setPrivacyChoice - onFailure()", t.getMessage(), t);
                        dialogDelay();
                    }
                });
    }

    private void dialogDelay() {
        new Handler().postDelayed(() -> isUploadMLD.setValue(false), 500);
    }

}
