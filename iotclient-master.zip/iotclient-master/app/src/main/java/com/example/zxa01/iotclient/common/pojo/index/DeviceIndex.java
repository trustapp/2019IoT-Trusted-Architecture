package com.example.zxa01.iotclient.common.pojo.index;


public class DeviceIndex {
    private String udn;

    public DeviceIndex(){

    }

    public String getUdn() {
        return udn;
    }

    public void setUdn(String udn) {
        this.udn = udn;
    }
}
