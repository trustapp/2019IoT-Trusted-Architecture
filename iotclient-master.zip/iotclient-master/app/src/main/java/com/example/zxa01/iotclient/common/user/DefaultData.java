package com.example.zxa01.iotclient.common.user;

import com.example.zxa01.iotclient.common.pojo.auth.LoginMessage;

public class DefaultData {

    private static DefaultData defaultData = new DefaultData();
    private LoginMessage loginMessage;
    public String address = "http://192.168.2.114";
    public String gatewayPort= "8080";
    public String cloudPort = "8081";

    private DefaultData() {
        loginMessage = new LoginMessage(address,gatewayPort,cloudPort, "user", "1234");
    }

    public static DefaultData getDefaultData() {
        return defaultData;
    }

    public LoginMessage getLoginMessage() {
        return loginMessage;
    }

}
