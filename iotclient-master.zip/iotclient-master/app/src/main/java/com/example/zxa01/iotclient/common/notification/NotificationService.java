package com.example.zxa01.iotclient.common.notification;

import android.app.DownloadManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

public class NotificationService {

    public static final String CHANNELID = "118";
    private NotificationManager notificationManager;
    private NotificationCompat.Builder builder;

    private Context context;
    private Intent intent;
    private String contentTitle;
    private String contentText;

    public NotificationService(Context context, String contentTitle, String contentText,Intent intent) {
        this.context = context;
        this.contentTitle = contentTitle;
        this.contentText = contentText;
        this.intent = intent;
    }

    public void build() {
        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }
        int NOTIFY_ID = 0;
        builder = new NotificationCompat.Builder(context, CHANNELID);
        builder.setContentTitle(contentTitle)
                .setContentText(contentText)
                .setTicker(contentTitle)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setDefaults(android.app.Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setVibrate(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});

        if(intent != null){
            builder.setContentIntent(PendingIntent.getActivity(context,0,intent,0));
        }
        android.app.Notification notification = builder.build();
        notificationManager.notify(NOTIFY_ID, notification);
    }


}
