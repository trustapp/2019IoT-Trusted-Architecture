package com.example.zxa01.iotclient.component.home.device.bind;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Context;
import android.content.Intent;
import android.databinding.ObservableField;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;

import com.example.zxa01.iotclient.R;
import com.example.zxa01.iotclient.component.home.HomeActivity;

public class DeviceBindViewModel extends ViewModel {

    private static final String QRCODE_MARKET = "market://details?id=com.google.zxing.client.android";
    private static final String QRCODE_INTENT = "com.google.zxing.client.android.SCAN";
    private static final String QRCODE_MODE = "SCAN_MODE";
    private static final String QRCODE_CODE_MODE = "QR_CODE_MODE";
    private static final int QRCODE_REQUEST_CODE = 0;

    public ObservableField<String> udn = new ObservableField<>();
    private DeviceBindModel deviceBindModel = new DeviceBindModel();
    private Fragment fragment;
    private Context context;
    private AlertDialog dialog;

    public DeviceBindViewModel(Context context){
        this.context = context;
    }

    public DeviceBindViewModel(Fragment fragment) {
        this.fragment = fragment;
        this.context = fragment.getContext();
        drawDialog();
    }

    /**
     * binding
     */

    public void bindDeviceAndGateway(String udn) {
        deviceBindModel.bindDeviceAndGateway(udn);
        context.startActivity(new Intent(context,HomeActivity.class));
    }


    public void qrcode() {
        try {
            fragment.startActivityForResult(
                    new Intent(QRCODE_INTENT)
                            .putExtra(QRCODE_MODE, QRCODE_CODE_MODE)
                    , QRCODE_REQUEST_CODE);
        } catch (Exception e) {
            fragment.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(QRCODE_MARKET)));
        }
    }

    /**
     * UI
     */

    public void cancel() {
        ((DeviceBindFragment) fragment).dismiss();
    }

    public MutableLiveData<Boolean> observeIsLoadingMLD() {
        return deviceBindModel.getIsUploadMLD();
    }

    public void setIsUpload(Boolean isUpload) {
        if (isUpload) {
            dialog.show();
        } else {
            cancel();
            dialog.hide();
        }
    }

    private void drawDialog() {
        dialog = new AlertDialog.Builder(fragment.getContext())
                .setMessage(R.string.bind_binding_waiting)
                .setTitle(R.string.bind_waiting)
                .create();
    }


}
