# IOTClient

科技部 Client 端 Demo 程式。
* 主要呈現使用者如何表達隱私選項及檢視所表達的隱私選擇記錄。
* 登入授權由其他子計畫實作，故本 Demo 僅使用簡單登入作為呈現。

### Environment

* Android API 27
* Java 8

### Design Pattern

* MVVM on Android

### Compontent

* Login `登入頁面`

* Home `主畫面`
  - Device `裝置列表`
  - Record `隱私選擇記錄`
  - Setting `系統設定`
 
* Detail `裝置詳細資訊`

* Privacy `裝置隱私政策（可表達選項）`

