package com.example.myapplication;

public class Setting {

    static final String spu = "1000";
    static final String gatewayURL = "http://localhost:8003";
    static final String serverURL = "http://140.119.164.146:3000";
    static final String op = "CDC202D5123E20F62B6D676AC72CB318";
    static final String Xs = "gateway";
}
