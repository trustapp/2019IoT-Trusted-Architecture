package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.example.myapplication.Setting.serverURL;


public class historyBloodActivity extends AppCompatActivity {

    Button  eighthourGraph,onedayGraph,onedweekGraph;
    TextView textview;
    Intent intent;
    private Bundle bundle;

    private RequestQueue queue;
    //private sessionManager sessionHelper;
    //private String allrole;
    //private sessionManager sessionHelper= null;

    String dtype = "";
    String rorh = "";
    String URL = "";
    String GatewayID = "";
    String RoleID = "";


    TextView txtSensor,txtYaxis,txtXaxis;
    LineChart graphSensor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historyblood);
        initModule();
        initLayout();
        initListener();
        /*
        //bundle = historyUVActivity.this.getIntent().getExtras();
        dtype = bundle.getString("datatype");
        rorh = bundle.getString("rorh");
        GatewayID = bundle.getString("gatewayid");
        RoleID = bundle.getString("roleid");*/
        Log.i("datatype : ", dtype);
        //txtSensor.setText(setDataType(dtype));
        //txtYaxis.setText(setDataType2(dtype));
        dtype = "1";
        rorh = "history";
        GatewayID = "tommy";
        RoleID = "tommy";

        URL = serverURL + "/gethistorydata";

        //getData();
    }


    private void initModule() {
        //bundle = getIntent().getExtras();
        //allrole = bundle.getString("Role");
        queue = Volley.newRequestQueue(historyBloodActivity.this);
        //sessionHelper = new sessionManager(getApplicationContext());
    }


    private void initLayout() {
        textview = (TextView) findViewById(R.id.textView50);
        eighthourGraph = (Button) findViewById(R.id.button4);
        onedayGraph = (Button) findViewById(R.id.button5);
        onedweekGraph = (Button) findViewById(R.id.button3);
        //txtSensor = (TextView)findViewById(R.id.sensor);
        txtXaxis = (TextView)findViewById(R.id.Xaxis);
        txtYaxis = (TextView)findViewById(R.id.Yaxis);
        graphSensor = (LineChart) findViewById(R.id.graph_sensor);
        //graphSensor.setDescription("");
        configCharAxis(graphSensor);
    }


    private void initListener() {
        eighthourGraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtXaxis.setText("Hour");
                textview.setText("目前感測數據：        8 Hours");
                getRequest(8,1);
                //getData(8);
            }
        });
        onedayGraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtXaxis.setText("3 Hours");
                textview.setText("目前感測數據：        1 Day");
                getRequest(24,1);
                //getData(24);
            }
        });
        onedweekGraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtXaxis.setText("1 Day");
                textview.setText("目前感測數據：        One Week");
                getRequest(168,1);
                //getData(168);
            }
        });
    }







    private String setDataType(String type){
        switch(type){
            case "1":
                return "血氧感測裝置-血氧";
            case "2":
                return "心跳感測裝置-心跳";
            case "3":
                return "溫度感測裝置";
            case "4":
                return "濕度感測裝置";
            case "5":
                return "PM2.5";
            case "6":
                return "紫外線感測裝置";
            case "7":
                return "甲烷";
            case "8":
                return "天然氣";
            default:
                return null;
        }
    }


    private String setDataType2(String type){
        switch(type){
            case "1":
                return "%";
            case "2":
                return "bpm";
            case "3":
                return "°C";
            case "4":
                return "%";
            case "5":
                return "μg/m3";
            case "6":
                return "Level";
            case "7":
                return "ppm";
            case "8":
                return "unknown";

            default:
                return null;
        }
    }



    private String setDataType3(String type){
        switch(type){
            case "1":
                return "Blood";
            case "2":
                return "Heart";
            case "3":
                return "Temperature";
            case "4":
                return "Humidity";
            case "5":
                return "PM2.5";
            case "6":
                return "UV Level";
            case "7":
                return "Methane";
            case "8":
                return "Naturalgas";
            default:
                return null;
        }
    }



    private void configCharAxis(LineChart chartLine){
        XAxis xAxis = chartLine.getXAxis();
        xAxis.setTextSize(6);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        YAxis rYAxis = chartLine.getAxisRight();
        rYAxis.setEnabled(false);
    }



    private void getRequest(final int T, int ddtype){
        /*
        final String UserId = sessionHelper.getUserID();
        String token = sessionHelper.getToken();
        Log.i("Get data token : ",token);
        */
        JSONObject request = new JSONObject();
        //getData(8);

        //int tt = T;
        try {
            //request.put("UserID","tommy");
            //request.put("utoken","tommy");
            request.put("datatype",setDataType3(Integer.toString(ddtype)));
            request.put("interval",T);
            //request.put("roleid",RoleID);
            //request.put("gatewayid",GatewayID);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        //getData(168);
        JsonObjectRequest strReq = new JsonObjectRequest(Request.Method.POST, URL, request,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject responseObj) {
                        String res = responseObj.toString();
                        Log.e("resOBJ: ",  res);
                        //getData(24);
                        if(responseObj != null) {
                            //getData(168);
                        }
                        //String response = responseObj.getString("secret data");

                        try {
                            //getData(168);
                            String response = responseObj.getString("secret data");

                            Log.e("123", response );
                            generateGraph(response);
                            //getData(T);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Can not post request to server1", Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("MenuVolleyError---", error.getMessage(), error);
                        byte[] htmlBodyBytes = error.networkResponse.data;
                        Log.e("VolleyError body---->", new String(htmlBodyBytes), error);
                        Toast.makeText(getApplicationContext(), "Can not post request to server2", Toast.LENGTH_LONG).show();
                    }
                }
        );
        //getData(168);
        queue.add(strReq);
    }


    private void generateGraph(String response) throws JSONException {

        graphSensor.clear();
        txtYaxis.setText(setDataType2(dtype));
        Log.e("168",response);
        String jsonString = "[{Value: 1} , {Value: 2}]";
        JSONArray obj = new JSONArray(response);

        Log.e("159",obj.toString());

        //time list
        //List<String> dateSensor = new ArrayList<>();
        //value list
        List<Entry> dataSensor = new ArrayList<>();

        for(int i=0; i<obj.length(); i++){
            //obj.getJSONObject(i).getString("TimeStamp");
            //dateSensor.add(obj.getJSONObject(i).getString("TimeStamp"));
            dataSensor.add(new Entry(i,Float.parseFloat(obj.getJSONObject(i).getString("Value"))));
            //dataSensor.add(new Entry(Float.parseFloat(obj.getJSONObject(i).getString("Value")),i));
        }
        //dataSensor.add(new Entry(Float.parseFloat("2"), 30));
        LineDataSet dataSetSensor = new LineDataSet(dataSensor, setDataType(dtype));
        //LineData ldSensor = new LineData(dateSensor,dataSetSensor);
        LineData ldSensor = new LineData(dataSetSensor);
        graphSensor.setData(ldSensor);
        graphSensor.setData(ldSensor);
        graphSensor.setVisibility(View.VISIBLE);
    }


}